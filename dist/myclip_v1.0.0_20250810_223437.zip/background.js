let selectedText = '';
let currentUrl = '';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "saveToMyClip",
    title: "Save to myClip",
    contexts: ["selection"]
  });
  
  chrome.storage.sync.set({
    serviceId: "service_xru7eg8",
    templateId: "template_qslbpku", 
    publicKey: "7eX6GLgodFTAfym7j",
    emailAddress: ""
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "saveToMyClip") {
    selectedText = info.selectionText;
    currentUrl = tab.url;
    
    chrome.tabs.sendMessage(tab.id, {
      action: "textSelected",
      text: selectedText,
      url: currentUrl
    });
    
    chrome.action.openPopup();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getSelectedData") {
    sendResponse({
      text: selectedText,
      url: currentUrl
    });
  }
  
  if (message.action === "clearSelectedData") {
    selectedText = '';
    currentUrl = '';
  }
});