document.addEventListener('DOMContentLoaded', async () => {
  const titleInput = document.getElementById('title');
  const contentTextarea = document.getElementById('content');
  const urlInput = document.getElementById('url');
  const saveBtn = document.getElementById('saveBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const status = document.getElementById('status');
  const form = document.getElementById('clipForm');

  await loadSelectedData();
  
  settingsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    await saveClip();
  });

  async function loadSelectedData() {
    try {
      const response = await chrome.runtime.sendMessage({action: "getSelectedData"});
      
      if (response && response.text) {
        contentTextarea.value = response.text;
        urlInput.value = response.url || '';
        titleInput.focus();
      } else {
        contentTextarea.value = '텍스트를 선택한 후 우클릭하여 "Save to myClip"을 클릭하세요.';
        saveBtn.disabled = true;
      }
    } catch (error) {
      console.error('Error loading selected data:', error);
    }
  }

  async function saveClip() {
    const title = titleInput.value.trim();
    const content = contentTextarea.value.trim();
    const url = urlInput.value.trim();

    if (!title) {
      showStatus('제목을 입력하세요.', 'error');
      return;
    }

    if (!content || content === '텍스트를 선택한 후 우클릭하여 "Save to myClip"을 클릭하세요.') {
      showStatus('저장할 콘텐츠가 없습니다.', 'error');
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = '전송 중...';
    
    try {
      const settings = await chrome.storage.sync.get([
        'serviceId', 
        'templateId', 
        'publicKey', 
        'emailAddress'
      ]);

      if (!settings.emailAddress) {
        showStatus('설정에서 이메일 주소를 입력하세요.', 'error');
        return;
      }

      emailjs.init(settings.publicKey);

      const templateParams = {
        name: title,
        time: new Date().toLocaleString('ko-KR'),
        message: `${content}\n\n출처: ${url}`,
        to_email: settings.emailAddress
      };

      await emailjs.send(
        settings.serviceId,
        settings.templateId,
        templateParams
      );

      showStatus('✅ 이메일이 성공적으로 전송되었습니다!', 'success');
      
      chrome.runtime.sendMessage({action: "clearSelectedData"});
      
      setTimeout(() => {
        window.close();
      }, 2000);

    } catch (error) {
      console.error('Email sending failed:', error);
      showStatus('❌ 이메일 전송에 실패했습니다. 설정을 확인하세요.', 'error');
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = '저장하기';
    }
  }

  function showStatus(message, type) {
    status.textContent = message;
    status.className = `status ${type}`;
    status.classList.remove('hidden');
    
    setTimeout(() => {
      status.classList.add('hidden');
    }, 5000);
  }
});